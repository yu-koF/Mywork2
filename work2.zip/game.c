#include<GL/glut.h>
#include<GL/glpng.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void Display(void);
void Reshape(int ,int );
void Timer(int);
void PutSprite(int ,int ,int ,pngInfo *);
void Keyboard(unsigned char, int ,int );
void SpecialKey(int , int ,int );
void Hunt(void);
void StarTalk(void);
void HelloWorld(void);
void True(void);
void BlueGate(void);
void GreenGate(void);
void Key(void);
void Eye0(void);
void Eye1t(void);
void Eye1f(void);
void Eye2(void);

GLuint img1[13];
pngInfo info1[13];

GLuint img2[16];
pngInfo info2[16];

GLuint img3[6];
pngInfo info3[6];

GLuint img4[7];
pngInfo info4[7];


GLuint me[12];
pngInfo meinfo[12];

GLuint un[3];
pngInfo uninfo[3];

GLuint say[48];
pngInfo sayinfo[48];

GLuint ed[4];
pngInfo edinfo[4];

int px = 13*32 , py = 7*32 ; 
int pt = 2 ;
int h = 2 ;
int flag=0 ;
int red=1;
int blue=0;
int green=0;
int tg=0;
int map=1;
int kx=608,ky=288;
int sx=416,sy=320;
int rx=376,ry=256;
int bx=408,by=288;
int gx=440,gy=256;
int ux=13*32,uy=5*32;
int mod=0;
int sayx=0,sayy=480;
int start=0;
int hello;
int eye=0;

char map1[20][30]={"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAFAAAAAAGAAAAAAHAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAEEEAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAEEEEEAAAAAAAAAAAAAB",
		  "BAAAAAAAAAEEEEEEEAAAAAAAAAAAAB",
		  "BAAAAAAAAAAEEEEEAAAAAAAAAAAAAD",
		  "BAAAAAAAAAAAEEEAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BAAAAAAAAAAAAAAAAAAAAAAAAAAAAB",
		  "BBBBBBBBBBBBCBBBBBBBBBBBBBBBBB"};

char map2[20][30]={"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL",
		   "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL",
		   "LLLLLLLLLLLLHDDDDDDDDDDDDDILLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "DDDDDDDDDDDDMAAAAAAAAAAAAACLLL",
	 	   "NAAAAAAAAAAAAAAAAAAAAAAAPACLLL",
	  	   "EEEEEEEEEEEEJAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLBAAAAAAAAAAAAACLLL",
		   "LLLLLLLLLLLLFEEJAKEEEEEEEEGLLL",
		   "LLLLLLLLLLLLLLLBACLLLLLLLLLLLL",
		   "LLLLLLLLLLLLLLLBACLLLLLLLLLLLL",
		   "LLLLLLLLLLLLLLLBACLLLLLLLLLLLL",
		   "LLLLLLLLLLLLLLLBOCLLLLLLLLLLLL"};

char map3[20][30]={"DDDDDDDDDDDDDDDDCDDDDDDDDDDDDD",
		   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
	  	   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAAADDDDDDAAAAD",
	 	   "DAAAAAAAAAAAAAAAAAADDDDDDAAAAD",
		   "DAADDDDDDAAAAAAAAAAAAAAAAAAAAD",
		   "DAADDAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAADDAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAADDAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAADDAAAAAAAAAD",
		   "BAAAAAAAAAAAAAEAAADDAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DAAFFFAAAAAAAAAAAAAAAADAAAAAAD",
		   "DAAFFFAAAAAAAAAAAAAAADDAAAAAAD",
		   "DAAFFFAAAAAAAAAAADDDDDDAAAAAAD",
		   "DAAAAAAAAAAAAAAAADDDDDDAAAAAAD",
		   "DAAAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"};

char map4[20][30]={"BBBBBBBBBBBCBBBBBBBBBBBBBBBBBB",
		   "BBBBBBBBBBBABBBBBBBBBBBBBBBBBB",
		   "BBBBBBBBBBBABBBBBBBBBBBBBBBBBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAFAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAGAAAEAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAAAAD",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBAAAAAAAAAAAAAAAAAAAAAAAABBB",
		   "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
		   "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
		   "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"};

int main (int argc ,char **argv){

	char fname[20];
	char f[20];

	int i;

	srandom(12345);

	glutInit(&argc,argv);
	glutInitWindowSize(960,640);
	glutCreateWindow("dream");
	glutInitDisplayMode(GLUT_RGBA|GLUT_ALPHA);
	glClearColor(0.0,0.0,1.0,1.0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);

	for(i=0;i<13;i++){
		sprintf(fname,"map1 %d.png",i+1);
		img1[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&info1[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}

	for(i=0;i<16;i++){
		sprintf(fname,"map2 %d.png",i+1);
		img2[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&info2[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}
	for(i=0;i<6;i++){
		sprintf(fname,"map3 %d.png",i+1);
		img3[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&info3[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}

	for(i=0;i<7;i++){
		sprintf(fname,"map4 %d.png",i+1);
		img4[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&info4[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}


	for(i=0;i<12;i++){
		sprintf(f,"girlA %d.png",i+1);
		me[i]=pngBind(f,PNG_NOMIPMAP,PNG_ALPHA,&meinfo[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}

	for(i=0;i<3;i++){
		sprintf(fname,"unknown%d.png",i+1);
		un[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&uninfo[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}


	for(i=0;i<48;i++){
		sprintf(fname,"s%d.png",i+1);
		say[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&sayinfo[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}


	for(i=0;i<4;i++){
		sprintf(fname,"ending%d.png",i+1);
		ed[i]=pngBind(fname,PNG_NOMIPMAP,PNG_ALPHA,&edinfo[i],GL_CLAMP,GL_NEAREST,GL_NEAREST);
	}

	glutDisplayFunc(Display);
	glutReshapeFunc(Reshape);
	glutTimerFunc(1000,Timer,0);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(SpecialKey);


	glutMainLoop();

	return 0;
}

void HelloWorld(void){

	int i;

	mod=1;
	PutSprite(un[0],ux,uy,&uninfo[0]);

	for(i=0;i<5;i++){
		PutSprite(say[i+15],sayx,sayy,&sayinfo[i+15]);
		glFlush();
		Sleep(3000);
	}

	PutSprite(say[45],sayx,sayy,&sayinfo[45]);
	glFlush();
	Sleep(3000);

	PutSprite(say[0],sayx,sayy,&sayinfo[0]);
	glFlush();
	Sleep(3000);

	mod=0;
}

void Timer(int a){
	
	switch(h){
		case 1:
			if(flag==1){
				pt=10;
				flag=0;
			}else{
				pt=11;
				flag=1;
			}
			break;

		case 2:
			if(flag==1){
				pt=1;
				flag=0;
			}
			else{
				pt=2;
				flag=1;
			}
			break;

		case 3:
			if(flag==1){
				pt=4;
				flag=0;
			}
			else{
				pt=5;
				flag=1;
			}
			break;

		case 4:
			if(flag==1){
				pt=7;
				flag=0;
			}
			else{
				pt=8;
				flag=1;
			}
			break;
	}

	glutPostRedisplay();
	glutTimerFunc(350,Timer,0);
}

void Reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluOrtho2D(0,w,0,h);
	glScaled(1,-1,1);
	glTranslated(0,-h,0);
}

void Display(void){

	int i,j,k;


	glClear(GL_COLOR_BUFFER_BIT);

	if(map==1){
		for(i=0;i<20;i++){
			for(j=0;j<30;j++){
				k=map1[i][j];
				PutSprite(img1[k-'A'],j*32,i*32,&info1[k-'A']);
			}
		}
	}else if(map==2){
		for(i=0;i<20;i++){
			for(j=0;j<30;j++){
				k=map2[i][j];
				PutSprite(img2[k-'A'],j*32,i*32,&info2[k-'A']);
			}
		}
	}else if(map==3){
		for(i=0;i<20;i++){
			for(j=0;j<30;j++){
				k=map3[i][j];
				PutSprite(img3[k-'A'],j*32,i*32,&info3[k-'A']);
			}
		}
	}else if(map==4){
		for(i=0;i<20;i++){
			for(j=0;j<30;j++){
				k=map4[i][j];
				PutSprite(img4[k-'A'],j*32,i*32,&info4[k-'A']);
			}
		}
	}

	PutSprite(me[pt],px,py,&meinfo[pt]);

	if (start==0) { 
		HelloWorld();
		start=1;
	}

	if(eye==1)	PutSprite(say[13],0,0,&sayinfo[13]);

	glFlush();

}

void PutSprite(int num,int x,int y,pngInfo *info){
	int w,h;

	w=info->Width;
	h=info->Height;

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,num);
	glColor4ub(255,255,255,255);

	glBegin(GL_QUADS);

	glTexCoord2i(0,0);
	glVertex2i(x,y);

	glTexCoord2i(0,1);
	glVertex2i(x,y+h);

	glTexCoord2i(1,1);
	glVertex2i(x+w,y+h);

	glTexCoord2i(1,0);
	glVertex2i(x+w,y);

	glEnd();

	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
}

void Keyboard(unsigned char key,int x,int y){

	if(key==27){
		printf("Exit <Dream>\n");
		exit(0);
	}

	if(key==' '){
			if(map==1){
				if(h==1){
					if(px%32==0){
							if(map1[(py-1)/32][px/32]=='G'){
								if(red==1){
									Key();
									red=2;
								}else if(red==2){
									map1[2][13]='K';
								}
							}
							if(map1[(py-1)/32][px/32]=='F'){
								if(blue==1){
									Key();
									blue=2;
								}else if(blue==2){
									map1[2][6]='J';
								}else{
									BlueGate();
								}
							}
							if(map1[(py-1)/32][px/32]=='H'){
								if(green==1){
									Key();
									green=2;
								}else if(green==2){
									map1[2][20]='L';
								}else{
									GreenGate();
								}
							}
							if(map1[(py-1)/32][px/32]=='I'){
								if(tg==1){
									Key();
									tg=2;
								}else if(tg==2){
									map1[7][13]='M';
								}
							}
						}else if((map1[(py-1)/32][px/32]=='G'||map1[(py-1)/32][(px/32)+1]=='G')){
								if(red==1){
									Key();
									red=2;
								}else if(red==2){
									map1[2][13]='K';
								}
						}else if((map1[(py-1)/32][px/32]=='F'||map1[(py-1)/32][(px/32)+1]=='F')){
								if(blue==1){
									Key();
									blue=2;
								}else if(blue==2){
									map1[2][6]='J';
								}else{
									BlueGate();
								}
						}else if((map1[(py-1)/32][px/32]=='H'||map1[(py-1)/32][(px/32)+1]=='H')){
								if(green==1){
									Key();
									green=2;
								}else if(green==2){
									map1[2][20]='L';
								}else{
									GreenGate();
								}
						}else if((map1[(py-1)/32][px/32]=='I'||map1[(py-1)/32][(px/32)+1]=='I')){
								if(tg==1){
									Key();
									tg=2;
								}else if(tg==2){
									map1[7][13]='M';
								}
						}
				}else if(h==2){
					if(px%32==0){
						if(map1[(py/32)+1][px/32]=='G'){
							if(red==1){
								Key();
								red=2;
							}else if(red==2){
								map1[2][13]='K';
							}
						}
						if(map1[(py/32)+1][px/32]=='F'){
							if(blue==1){
								Key();
								blue=2;
							}else if(blue==2){
								map1[2][6]='J';
							}else{
								BlueGate();
							}
						}
						if(map1[(py/32)+1][px/32]=='H'){
							if(green==1){
								Key();
								green=2;
							}else if(green==2){
								map1[2][20]='L';
							}else{
								GreenGate();
							}
						}
						if(map1[(py/32)+1][px/32]=='I'){
							if(tg==1){
								Key();
								tg=2;
							}else if(tg==2){
								map1[7][13]='M';
							}
						}
					}else if((map1[(py/32)+1][px/32]=='G'||map1[(py/32)+1][(px/32)+1]=='G')){
							if(red==1){
								Key();
								red=2;
							}else if(red==2){
								map1[2][13]='K';
							}
					}else if((map1[(py/32)+1][px/32]=='F'||map1[(py/32)+1][(px/32)+1]=='F')){
							if(blue==1){
								Key();
								blue=2;
							}else if(blue==2){
								map1[2][6]='J';
							}else{
								BlueGate();
							}
					}else if((map1[(py/32)+1][px/32]=='H'||map1[(py/32)+1][(px/32)+1]=='H')){
							if(green==1){
								Key();
								green=2;
							}else if(green==2){
								map1[2][20]='L';
							}else{
								GreenGate();
							}
					}else if((map1[(py/32)+1][px/32]=='I'||map1[(py/32)+1][(px/32)+1]=='I')){
							if(tg==1){
								Key();
								tg=2;
							}else if(tg==2){
								map1[7][13]='M';
							}
					}
				}else if(h==3){
					if(py%32==0){
						if(map1[py/32][(px-1)/32]=='G'){
							if(red==1){
								Key();
								red=2;
							}else if(red==2){
								map1[2][13]='K';
							}
						}
						if(map1[py/32][(px-1)/32]=='F'){
							if(blue==1){
								Key();
								blue=2;
							}else if(blue==2){
								map1[2][6]='J';
							}else{
								BlueGate();
							}
						}
						if(map1[py/32][(px-1)/32]=='H'){
							if(green==1){
								Key();
								green=2;
							}else if(green==2){
								map1[2][20]='L';
							}else{
								GreenGate();
							}
						}
						if(map1[py/32][(px-1)/32]=='I'){
							if(tg==1){
								Key();
								tg=2;
							}else if(tg==2){
								map1[7][13]='M';
							}
						}
					}else if((map1[py/32][(px-1)/32]=='G'||map1[(py/32)+1][(px-1)/32]=='G')){
						if(red==1){
							Key();
							red=2;
						}else if(red==2){
							map1[2][13]='K';
						}
					}else if((map1[py/32][(px-1)/32]=='F'||map1[(py/32)+1][(px-1)/32]=='F')){
						if(blue==1){
							Key();
							blue=2;
						}else if(blue==2){
							map1[2][6]='J';
						}else {
							BlueGate();
						}
					}else if((map1[py/32][(px-1)/32]=='H'||map1[(py/32)+1][(px-1)/32]=='H')){
						if(green==1){
							Key();
							green=2;
						}else if(green==2){
							map1[2][20]='L';
						}else{
							GreenGate();
						}
					}else if((map1[py/32][(px-1)/32]=='I'||map1[(py/32)+1][(px-1)/32]=='I')){
						if(tg==1){
							Key();
							tg=2;
						}else if(tg==2){
							map1[7][13]='M';
						}
					}
				}else if(h==4){
					if(py%32==0){
						if(map1[py/32][(px/32)+1]=='G'){
							if(red==1){
								Key();
								red=2;
							}else if(red==2){
								map1[2][13]='K';
							}
						}
						if(map1[py/32][(px/32)+1]=='F'){
							if(blue==1){
								Key();
								blue=2;
							}else if(blue==2){
								map1[2][6]='J';
							}else{
								BlueGate();
							}
						}
						if(map1[py/32][(px/32)+1]=='H'){
							if(green==1){
								Key();
								green=2;
							}else if(green==2){
								map1[2][20]='L';
							}else{
								GreenGate();
							}
						}
						if(map1[py/32][(px/32)+1]=='I'){
							if(tg==1){
								Key();
								tg=2;
							}else if(tg==2){
								map1[7][13]='M';
							}
						}
					}else if((map1[py/32][(px/32)+1]=='G'||map1[(py/32)+1][(px/32)+1]=='G')){
							if(red==1){
								Key();
								red=2;
							}else if(red==2){
								map1[2][13]='K';
							}
					}else if((map1[py/32][(px/32)+1]=='F'||map1[(py/32)+1][(px/32)+1]=='F')){
							if(blue==1){
								Key();
								blue=2;
							}else if(blue==2){
								map1[2][6]='J';
							}else{
								BlueGate();
							}
					}else if((map1[py/32][(px/32)+1]=='H'||map1[(py/32)+1][(px/32)+1]=='H')){
							if(green==1){
								Key();
								green=2;
							}else if(green==2){
								map1[2][20]='L';
							}else{
								GreenGate();
							}
					}else if((map1[py/32][(px/32)+1]=='I'||map1[(py/32)+1][(px/32)+1]=='I')){
							if(tg==1){
								Key();
								tg=2;
							}else if(tg==2){
								map1[7][13]='M';
							}
					}
				}
			}
			if(map==2){
				if(h==1){
						if(px%32==0){
							if(map2[(py-1)/32][px/32]=='P'){
								True();
							}
						}else if((map2[(py-1)/32][px/32]=='P'||map2[(py-1)/32][(px/32)+1]=='P')){
								True();
						}
				}else if(h==2){
					if(px%32==0){
						if(map2[(py/32)+1][px/32]=='P'){
							True();
						}
					}else if((map2[(py/32)+1][px/32]=='P'||map2[(py/32)+1][(px/32)+1]=='P')){
							True();
					}
				}else if(h==3){
					if(py%32==0){
						if(map2[py/32][(px-1)/32]=='P'){
							True();
						}
						
					}else if((map2[py/32][(px-1)/32]=='P'||map2[(py/32)+1][(px-1)/32]=='P')){
						True();
					}
				}else if(h==4){
					if(py%32==0){
						if(map2[py/32][(px/32)+1]=='P'){
							True();
						}
					}else if((map2[py/32][(px/32)+1]=='P'||map2[(py/32)+1][(px/32)+1]=='P')){
							True();
					}
				}
			}
			if(map==3){
				if(h==1){
						if(px%32==0){
							if(map3[(py-1)/32][px/32]=='F'){
								Hunt();
							}else if(map3[(py-1)/32][px/32]=='E'){
								StarTalk();
							}
						}else if((map3[(py-1)/32][px/32]=='F'||map3[(py-1)/32][(px/32)+1]=='F')){
								Hunt();
						}else if((map3[(py-1)/32][px/32]=='E'||map3[(py-1)/32][(px/32)+1]=='E')){
								StarTalk();
						}
				}else if(h==2){
					if(px%32==0){
						if(map3[(py/32)+1][px/32]=='F'){
							Hunt();
						}else if(map3[(py/32)+1][px/32]=='E'){
							StarTalk();
						}
					}else if((map3[(py/32)+1][px/32]=='F'||map3[(py/32)+1][(px/32)+1]=='F')){
							Hunt();
					}else if((map3[(py/32)+1][px/32]=='E'||map3[(py/32)+1][(px/32)+1]=='E')){
							StarTalk();
					}
				}else if(h==3){
					if(py%32==0){
						if(map3[py/32][(px-1)/32]=='F'){
							Hunt();
						}else if(map3[py/32][(px-1)/32]=='E'){
							StarTalk();
						}
						
					}else if((map3[py/32][(px-1)/32]=='F'||map3[(py/32)+1][(px-1)/32]=='F')){
						Hunt();
					}else if((map3[py/32][(px-1)/32]=='E'||map3[(py/32)+1][(px-1)/32]=='E')){
						StarTalk();
					}
				}else if(h==4){
					if(py%32==0){
						if(map3[py/32][(px/32)+1]=='F'){
							Hunt();}
						}else if(map3[py/32][(px/32)+1]=='E'){
							StarTalk();
						}
					}else if((map3[py/32][(px/32)+1]=='F'||map3[(py/32)+1][(px/32)+1]=='F')){
							Hunt();
					}else if((map3[py/32][(px/32)+1]=='E'||map3[(py/32)+1][(px/32)+1]=='E')){
							StarTalk();
					}
				}
			}
			if(map==4){
				if(h==1){
						if(px%32==0){
							if(map4[(py-1)/32][px/32]=='E'||map4[(py-1)/32][px/32]=='F'||map4[(py-1)/32][px/32]=='G'){
								if(eye==0){
									Eye0();
								}else if(eye==1){
									if(map4[(py-1)/32][px/32]=='E') Eye1t();
									else Eye1f();
								}else {
									Eye2();
								}
							}
						}else if((map4[(py-1)/32][px/32]=='E'||map4[(py-1)/32][(px/32)+1]=='E')||(map4[(py-1)/32][px/32]=='F'||map4[(py-1)/32][(px/32)+1]=='F')||(map4[(py-1)/32][px/32]=='G'||map4[(py-1)/32][(px/32)+1]=='G')){
								if(eye==0){
									Eye0();
								}else if(eye==1){
									if(map4[(py-1)/32][px/32]=='E'||map4[(py-1)/32][(px/32)+1]=='E') Eye1t();
									else Eye1f();
								}else {
									Eye2();
								}
						}
				}else if(h==2){
					if(px%32==0){
						if(map4[(py/32)+1][px/32]=='E'||map4[(py/32)+1][px/32]=='F'||map4[(py/32)+1][px/32]=='G'){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[(py/32)+1][px/32]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
						}
					}else if((map4[(py/32)+1][px/32]=='E'||map4[(py/32)+1][(px/32)+1]=='E')||(map4[(py/32)+1][px/32]=='F'||map4[(py/32)+1][(px/32)+1]=='F')||(map4[(py/32)+1][px/32]=='G'||map4[(py/32)+1][(px/32)+1]=='G')){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[(py/32)+1][px/32]=='E'||map4[(py/32)+1][(px/32)+1]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
					}
				}else if(h==3){
					if(py%32==0){
						if(map4[py/32][(px-1)/32]=='E'||map4[py/32][(px-1)/32]=='F'||map4[py/32][(px-1)/32]=='G'){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[(py-1)/32][px/32]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
						}
						
					}else if((map4[py/32][(px-1)/32]=='E'||map4[(py/32)+1][(px-1)/32]=='E')||(map4[py/32][(px-1)/32]=='F'||map4[(py/32)+1][(px-1)/32]=='F')||(map4[py/32][(px-1)/32]=='G'||map4[(py/32)+1][(px-1)/32]=='G')){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[py/32][(px-1)/32]=='E'||map4[(py/32)+1][(px-1)/32]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
					}
				}else if(h==4){
					if(py%32==0){
						if(map4[py/32][(px/32)+1]=='E'||map4[py/32][(px/32)+1]=='F'||map4[py/32][(px/32)+1]=='G'){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[py/32][(px/32)+1]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
						}
					}else if((map4[py/32][(px/32)+1]=='E'||map4[(py/32)+1][(px/32)+1]=='E')||(map4[py/32][(px/32)+1]=='F'||map4[(py/32)+1][(px/32)+1]=='F')||(map4[py/32][(px/32)+1]=='G'||map4[(py/32)+1][(px/32)+1]=='G')){
							if(eye==0){
								Eye0();
							}else if(eye==1){
								if(map4[py/32][(px/32)+1]=='E'||map4[(py/32)+1][(px/32)+1]=='E') Eye1t();
								else Eye1f();
							}else {
								Eye2();
							}
					}
				}
			}
		
}

void SpecialKey(int key, int x,int y){
	int z;
	z=map;

	if(mod==0){
	if(map==1){
	switch(key){
		case GLUT_KEY_UP:
			h=1;
			if(py>0){
				if(px%32==0){
					if(map1[(py-1)/32][px/32]!='B'&&map1[(py-1)/32][px/32]!='F'&&map1[(py-1)/32][px/32]!='G'&&map1[(py-1)/32][px/32]!='H'){
						py-=4;
					}
				}else if((map1[(py-1)/32][px/32]!='B'&&map1[(py-1)/32][(px/32)+1]!='B')&&(map1[(py-1)/32][px/32]!='F'&&map1[(py-1)/32][(px/32)+1]!='F')&&(map1[(py-1)/32][px/32]!='G'&&map1[(py-1)/32][(px/32)+1]!='G')&&(map1[(py-1)/32][px/32]!='H'&&map1[(py-1)/32][(px/32)+1]!='H')&&(map1[(py-1)/32][px/32]!='I'&&map1[(py-1)/32][(px/32)+1]!='I')){
						py-=4;
				}
			}
			break;
		case GLUT_KEY_DOWN:
			h=2;
			if(py<620) {
				if(px%32==0){
					if(map1[(py/32)+1][px/32]!='B'&&map1[(py/32)+1][px/32]!='F'&&map1[(py/32)+1][px/32]!='G'&&map1[(py/32)+1][px/32]!='H'){
						py+=4;
					}
				}else if((map1[(py/32)+1][px/32]!='B'&&map1[(py/32)+1][(px/32)+1]!='B')&&(map1[(py/32)+1][px/32]!='F'&&map1[(py/32)+1][(px/32)+1]!='F')&&(map1[(py/32)+1][px/32]!='G'&&map1[(py/32)+1][(px/32)+1]!='G')&&(map1[(py/32)+1][px/32]!='H'&&map1[(py/32)+1][(px/32)+1]!='H')&&(map1[(py/32)+1][px/32]!='I'&&map1[(py/32)+1][(px/32)+1]!='I')){
						py+=4;
				}
			}
			break;
		case GLUT_KEY_LEFT:
			h=3;
			if(px>0){
				if(py%32==0){
					if(map1[py/32][(px-1)/32]!='B'&&map1[py/32][(px-1)/32]!='F'&&map1[py/32][(px-1)/32]!='G'&&map1[py/32][(px-1)/32]!='H'){
						px-=4;
					}
				}else if((map1[py/32][(px-1)/32]!='B'&&map1[(py/32)+1][(px-1)/32]!='B')&&(map1[py/32][(px-1)/32]!='F'&&map1[(py/32)+1][(px-1)/32]!='F')&&(map1[py/32][(px-1)/32]!='G'&&map1[(py/32)+1][(px-1)/32]!='G')&&(map1[py/32][(px-1)/32]!='H'&&map1[(py/32)+1][(px-1)/32]!='H')&&(map1[py/32][(px-1)/32]!='I'&&map1[(py/32)+1][(px-1)/32]!='I')){
						px-=4;
				}
			}
			break;
		case GLUT_KEY_RIGHT:
			h=4;
			if(px<940){
				if(py%32==0){
					if(map1[py/32][(px/32)+1]!='B'&&map1[py/32][(px/32)+1]!='F'&&map1[py/32][(px/32)+1]!='G'&&map1[py/32][(px/32)+1]!='H'){
						px+=4;
					}
				}else if((map1[py/32][(px/32)+1]!='B'&&map1[(py/32)+1][(px/32)+1]!='B')&&(map1[py/32][(px/32)+1]!='F'&&map1[(py/32)+1][(px/32)+1]!='F')&&(map1[py/32][(px/32)+1]!='G'&&map1[(py/32)+1][(px/32)+1]!='G')&&(map1[py/32][(px/32)+1]!='H'&&map1[(py/32)+1][(px/32)+1]!='H')&&(map1[py/32][(px/32)+1]!='I'&&map1[(py/32)+1][(px/32)+1]!='I')){
						px+=4;
				}
			}
			break;
	}
	}else if(map==2){
	switch(key){
		case GLUT_KEY_UP:
			h=1;
			if(py>0){
				if(px%32==0){
					if(map2[(py-1)/32][px/32]=='A'||map2[(py-1)/32][px/32]=='N'||map2[(py-1)/32][px/32]=='O'){
						py-=4;
					}
				}else if((map2[(py-1)/32][px/32]=='A'&&map2[(py-1)/32][(px/32)+1]=='A')||(map2[(py-1)/32][px/32]=='N'&&map2[(py-1)/32][(px/32)+1]=='N')||(map2[(py-1)/32][px/32]=='O'&&map2[(py-1)/32][(px/32)+1]=='O')){
						py-=4;
				}
			}
			break;
		case GLUT_KEY_DOWN:
			h=2;
			if(py<620) {
				if(px%32==0){
					if(map2[(py/32)+1][px/32]=='A'||map2[(py/32)+1][px/32]=='N'||map2[(py/32)+1][px/32]=='O'){
							py+=4;
					}
				}else if((map2[(py/32)+1][px/32]=='A'&&map2[(py/32)+1][(px/32)+1]=='A')||(map2[(py/32)+1][px/32]=='N'&&map2[(py/32)+1][(px/32)+1]=='N')||(map2[(py/32)+1][px/32]=='O'&&map2[(py/32)+1][(px/32)+1]=='O')){
						py+=4;
				}
			}
			break;
		case GLUT_KEY_LEFT:
			h=3;
			if(px>0){
				if(py%32==0){
					if(map2[py/32][(px-1)/32]=='A'||map2[py/32][(px-1)/32]=='N'||map2[py/32][(px-1)/32]=='O'){
						px-=4;
					}
				}else if((map2[py/32][(px-1)/32]=='A'&&map2[(py/32)+1][(px-1)/32]=='A')||(map2[py/32][(px-1)/32]=='N'&&map2[(py/32)+1][(px-1)/32]=='N')||(map2[py/32][(px-1)/32]=='O'&&map2[(py/32)+1][(px-1)/32]=='O')){
						px-=4;
				}
			}
			break;
		case GLUT_KEY_RIGHT:
			h=4;
			if(px<940){
				if(py%32==0){
					if(map2[py/32][(px/32)+1]=='A'||map2[py/32][(px/32)+1]=='N'||map2[py/32][(px/32)+1]=='O'){
						px+=4;
					}
				}else if((map2[py/32][(px/32)+1]=='A'&&map2[(py/32)+1][(px/32)+1]=='A')||(map2[py/32][(px/32)+1]=='N'&&map2[(py/32)+1][(px/32)+1]=='N')||(map2[py/32][(px/32)+1]=='O'&&map2[(py/32)+1][(px/32)+1]=='O')){
						px+=4;
				}
			}
			break;
	}
	}else if(map==3){
	switch(key){
		case GLUT_KEY_UP:
			h=1;
			if(py>0){
				if(px%32==0){
					if(map3[(py-1)/32][px/32]!='D'&&map3[(py-1)/32][px/32]!='E'&&map3[(py-1)/32][px/32]!='F'){
						py-=4;
					}
				}else if(map3[(py-1)/32][px/32]!='D'&&map3[(py-1)/32][(px/32)+1]!='D'&&map3[(py-1)/32][px/32]!='E'&&map3[(py-1)/32][(px/32)+1]!='E'&&map3[(py-1)/32][px/32]!='F'&&map3[(py-1)/32][(px/32)+1]!='F'){
						py-=4;
				}
			}
			break;
		case GLUT_KEY_DOWN:
			h=2;
			if(py<620) {
				if(px%32==0){
					if(map3[(py/32)+1][px/32]!='D'&&map3[(py/32)+1][px/32]!='E'&&map3[(py/32)+1][px/32]!='F'){
						py+=4;
					}
				}else if(map3[(py/32)+1][px/32]!='D'&&map3[(py/32)+1][(px/32)+1]!='D'&&map3[(py/32)+1][px/32]!='E'&&map3[(py/32)+1][(px/32)+1]!='E'&&map3[(py/32)+1][px/32]!='F'&&map3[(py/32)+1][(px/32)+1]!='F'){
						py+=4;
				}
			}
			break;
		case GLUT_KEY_LEFT:
			h=3;
			if(px>0){
				if(py%32==0){
					if(map3[py/32][(px-1)/32]!='D'&&map3[py/32][(px-1)/32]!='E'&&map3[py/32][(px-1)/32]!='F'){
						px-=4;
					}
				}else if(map3[py/32][(px-1)/32]!='D'&&map3[(py/32)+1][(px-1)/32]!='D'&&map3[py/32][(px-1)/32]!='E'&&map3[(py/32)+1][(px-1)/32]!='E'&&map3[py/32][(px-1)/32]!='F'&&map3[(py/32)+1][(px-1)/32]!='F'){
						px-=4;
				}
			}
			break;
		case GLUT_KEY_RIGHT:
			h=4;
			if(px<940){
				if(py%32==0){
					if(map3[py/32][(px/32)+1]!='D'&&map3[py/32][(px/32)+1]!='E'&&map3[py/32][(px/32)+1]!='F'){
						px+=4;
					}
				}else if(map3[py/32][(px/32)+1]!='D'&&map3[(py/32)+1][(px/32)+1]!='D'&&map3[py/32][(px/32)+1]!='E'&&map3[(py/32)+1][(px/32)+1]!='E'&&map3[py/32][(px/32)+1]!='F'&&map3[(py/32)+1][(px/32)+1]!='F'){
						px+=4;
				}
			}
			break;
	}
	}else if(map==4){
	switch(key){
		case GLUT_KEY_UP:
			h=1;
			if(py>0){
				if(px%32==0){
					if(map4[(py-1)/32][px/32]!='B'&&map4[(py-1)/32][px/32]!='F'&&map4[(py-1)/32][px/32]!='G'&&map4[(py-1)/32][px/32]!='E'){
						py-=4;
					}
				}else if(map4[(py-1)/32][px/32]!='B'&&map4[(py-1)/32][(px/32)+1]!='B'&&map4[(py-1)/32][px/32]!='F'&&map4[(py-1)/32][(px/32)+1]!='F'&&map4[(py-1)/32][px/32]!='G'&&map4[(py-1)/32][(px/32)+1]!='G'&&map4[(py-1)/32][px/32]!='E'&&map4[(py-1)/32][(px/32)+1]!='E'){
						py-=4;
				}
			}
			break;
		case GLUT_KEY_DOWN:
			h=2;
			if(py<620) {
				if(px%32==0){
					if(map4[(py/32)+1][px/32]!='B'&&map4[(py/32)+1][px/32]!='F'&&map4[(py/32)+1][px/32]!='G'&&map4[(py/32)+1][px/32]!='E'){
						py+=4;
					}
				}else if(map4[(py/32)+1][px/32]!='B'&&map4[(py/32)+1][(px/32)+1]!='B'&&map4[(py/32)+1][px/32]!='F'&&map4[(py/32)+1][(px/32)+1]!='F'&&map4[(py/32)+1][px/32]!='G'&&map4[(py/32)+1][(px/32)+1]!='G'&&map4[(py/32)+1][px/32]!='E'&&map4[(py/32)+1][(px/32)+1]!='E'){
						py+=4;
				}
			}
			break;
		case GLUT_KEY_LEFT:
			h=3;
			if(px>0){
				if(py%32==0){
					if(map4[py/32][(px-1)/32]!='B'&&map4[py/32][(px-1)/32]!='F'&&map4[py/32][(px-1)/32]!='G'&&map4[py/32][(px-1)/32]!='E'){
						px-=4;
					}
				}else if(map4[py/32][(px-1)/32]!='B'&&map4[(py/32)+1][(px-1)/32]!='B'&&map4[py/32][(px-1)/32]!='F'&&map4[(py/32)+1][(px-1)/32]!='F'&&map4[py/32][(px-1)/32]!='G'&&map4[(py/32)+1][(px-1)/32]!='G'&&map4[py/32][(px-1)/32]!='E'&&map4[(py/32)+1][(px-1)/32]!='E'){
						px-=4;
				}
			}
			break;
		case GLUT_KEY_RIGHT:
			h=4;
			if(px<940){
				if(py%32==0){
					if(map4[py/32][(px/32)+1]!='B'&&map4[py/32][(px/32)+1]!='F'&&map4[py/32][(px/32)+1]!='G'&&map4[py/32][(px/32)+1]!='E'){
						px+=4;
					}
				}else if(map4[py/32][(px/32)+1]!='B'&&map4[(py/32)+1][(px/32)+1]!='B'&&map4[py/32][(px/32)+1]!='F'&&map4[(py/32)+1][(px/32)+1]!='F'&&map4[py/32][(px/32)+1]!='G'&&map4[(py/32)+1][(px/32)+1]!='G'&&map4[py/32][(px/32)+1]!='E'&&map4[(py/32)+1][(px/32)+1]!='E'){
						px+=4;
				}
			}
			break;
	}
	}
	}

	if(map==1){
		if(map1[py/32][px/32]=='D'){
			map=2;
			px=3*32;
			py=8*32;
		}
		if(map1[py/32][px/32]=='C'){
			map=4;
			px=11*32;
			py=3*32;
		}
	}else if(map==2){
		if(map2[py/32][px/32]=='N'){
			map=1;
			px=928;
			py=8*32;
		}
		if(map2[py/32][px/32]=='O'){
			map=3;
			px=16*32;
			py=64;
		}
	}else if(map==3){
		if(map3[py/32][px/32]=='C'){
			map=2;	
			px=16*32;
			py=608;
		}
		if(map3[py/32][px/32]=='B'){
			map=4;
			px=928;
			py=10*32;
		}
	}else if(map==4){
		if(map4[py/32][px/32]=='D'){
			map=3;
			px=64;
			py=9*32;
		}
		if(map4[py/32][px/32]=='C'){
			map=1;
			px=12*32;
			py=608;
		}
	}

	if(map==1){
		if(map1[py/32][px/32]=='J'){
			mod=1;
			PutSprite(ed[1],0,0,&edinfo[1]);
			glFlush();
			Sleep(3000);
			exit(0);
		}else if(map1[py/32][px/32]=='K'){
			mod=1;
			PutSprite(ed[0],0,0,&edinfo[0]);
			glFlush();
			Sleep(3000);
			exit(0);
		}else if(map1[py/32][px/32]=='L'){
			mod=1;
			PutSprite(ed[2],0,0,&edinfo[2]);
			glFlush();
			Sleep(3000);
			exit(0);
		}else if(map1[py/32][px/32]=='M'){
			mod=1;
			PutSprite(ed[3],0,0,&edinfo[3]);
			glFlush();
			Sleep(3000);
			exit(0);
		}
	}

	if(z!=map) Display();
}

void Hunt(void){
	if(green==0){
		mod=1;
		PutSprite(say[12],sayx,sayy,&sayinfo[12]);
		glFlush();
		Sleep(3000);
	        PutSprite(say[2],sayx,sayy,&sayinfo[2]);
	        glFlush();
	        Sleep(3000);
		green=1;
		mod=0;
	}
}

void StarTalk(void){
	int i;
	if(green==0){
		mod=1;
		for(i=0;i<2;i++){
			PutSprite(say[22+i],sayx,sayy,&sayinfo[22+i]);
			glFlush();
			Sleep(3000);
		}
		mod=0;
	}else if(green!=0){
		mod=1;
		for(i=0;i<2;i++){
			PutSprite(say[24+i],sayx,sayy,&sayinfo[24+i]);
			glFlush();
			Sleep(3000);
		}
		mod=0;
	}
}
void True(void){
	int i;
	if(red!=0&&blue!=0&&green!=0&&tg==0){
		mod=1;
		for(i=0;i<3;i++){
			PutSprite(say[41+i],sayx,sayy,&sayinfo[41+i]);
			glFlush();
			Sleep(3000);
		}
		PutSprite(say[3],sayx,sayy,&sayinfo[3]);
		glFlush();
		Sleep(3000);
		mod=0;
		tg=1;
		map1[7][13]='I';
	}else if(tg!=0){
		PutSprite(say[43],sayx,sayy,&sayinfo[43]);
		glFlush();
		Sleep(3000);
	}else {
		PutSprite(say[20],sayx,sayy,&sayinfo[20]);
		glFlush();
		Sleep(3000);
		PutSprite(say[21],sayx,sayy,&sayinfo[21]);
		glFlush();
		Sleep(3000);
		PutSprite(say[10],sayx,sayy,&sayinfo[10]);
		glFlush();
		Sleep(3000);
	}
}

void BlueGate(void){
	int i;
	mod=1;
	for(i=0;i<3;i++){
		PutSprite(say[4+i],sayx,sayy,&sayinfo[4+i]);
		glFlush();
		Sleep(3000);
	}
	PutSprite(say[10],sayx,sayy,&sayinfo[10]);
	glFlush();
	Sleep(3000);
	mod=0;
}

void GreenGate(void){
	int i;
	mod=1;
	PutSprite(say[4],sayx,sayy,&sayinfo[4]);
	glFlush();
	Sleep(3000);
	for(i=0;i<4;i++){
		PutSprite(say[7+i],sayx,sayy,&sayinfo[7+i]);
		glFlush();
		Sleep(3000);
	}
	PutSprite(say[10],sayx,sayy,&sayinfo[10]);
	glFlush();
	Sleep(3000);
	mod=0;
}

void Key(void){
	PutSprite(say[14],sayx,sayy,&sayinfo[14]);
	glFlush();
	Sleep(3000);
}

void Eye0(void){
	int i;
	mod=1;
	for(i=0;i<12;i++){
		PutSprite(say[26+i],sayx,sayy,&sayinfo[26+i]);
		glFlush();
		Sleep(3000);
	}
	for(i=0;i<3;i++){
		PutSprite(say[38+i],sayx,sayy,&sayinfo[38+i]);
		glFlush();
		Sleep(5000);
	}
	eye++;
	mod=0;
}

void Eye1t(void){
	mod=1;
	PutSprite(say[46],sayx,sayy,&sayinfo[46]);
	glFlush();
	Sleep(3000);
	PutSprite(say[1],sayx,sayy,&sayinfo[1]);
	glFlush();
	Sleep(3000);
	mod=0;
	blue=1;
	eye++;
}
void Eye1f(void){
	mod=1;
	PutSprite(say[47],sayx,sayy,&sayinfo[47]);
	glFlush();
	Sleep(3000);
	mod=0;
        eye++;
}

void Eye2(void){
	mod=1;
	PutSprite(say[31],sayx,sayy,&sayinfo[31]);
	glFlush();
	Sleep(3000);
	mod=0;
}